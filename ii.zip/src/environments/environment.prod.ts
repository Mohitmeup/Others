export const environment = {
  production: true,
  baseMwUrl:'http://localhost:7091'
};
