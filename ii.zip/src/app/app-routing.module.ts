import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {DashboardComponent} from './dashboard/dashboard.component';
import {GroupsComponent} from './groups/groups.component';
import {ContactFormComponent} from './contact-form/contact-form.component';
import {SearchContactComponent} from './search-contact/search-contact.component';
import {ContactsListComponent} from './contacts-list/contacts-list.component';
import {DebitlistComponent} from './debitlist/debitlist.component';
import {CarddetailsComponent} from '../app/carddetails/carddetails.component';
import{BlockdebitComponent} from './blockdebit/blockdebit.component'
import{UpgradeComponent} from './upgrade/upgrade.component';
import{ShowCardComponent} from './show-card/show-card.component';
import {DebitStatementComponent} from './debit-statement/debit-statement.component';
import{ApplynewdebitComponent}   from './applynewdebit/applynewdebit.component';
import{BankComponent}   from './bank/bank.component';
import{ListQueryComponent}   from './list-query/list-query.component';
import{ListUpgradeRequestsComponent} from './list-upgrade-requests/list-upgrade-requests.component';
import {ListCreditQueryComponent} from './list-credit-query/list-credit-query.component';
import{ListMismatchRequestsComponent} from'./list-mismatch-requests/list-mismatch-requests.component';
import{ListCreditUpdateRequestsComponent} from './list-credit-update-requests/list-credit-update-requests.component';
import{ListCreditMismatchRequestsComponent}from'./list-credit-mismatch-requests/list-credit-mismatch-requests.component';
import{ShowCreditListComponent} from './show-credit-list/show-credit-list.component';
import{ViewRequestsComponent} from './view-requests/view-requests.component';
import{ViewCustomerHistoryComponent} from './view-customer-history/view-customer-history.component'
import { from } from 'rxjs';

const routes: Routes = [
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'groups',component:GroupsComponent},
  {path:'contacts',component:ContactsListComponent},
  {path:'newContact',component:ContactFormComponent},
  {path:'editContact/:contactId',component:ContactFormComponent},
  {path:'search',component:SearchContactComponent},
  {path:'debit/debitlist',component:DebitlistComponent},
  {path:'carddetails',component:CarddetailsComponent},
  {path: 'block1', component:BlockdebitComponent},
  {path: 'debit/upgrade1', component:UpgradeComponent},
  {path: 'debit/getDetails', component:ShowCardComponent},
  {path: 'credit/getDetails', component:ShowCreditListComponent},
  {path:'debit/showStatement',component:DebitStatementComponent},
  {path:'debit/applynewdebit',component:ApplynewdebitComponent},
  {path:'banker',component:BankComponent},
  {path:'banker/viewnewDebitQueries',component:ListQueryComponent},
  {path:'queryStatus',component:ViewRequestsComponent},

  {path:'banker/viewCustomerHistory',component:ViewCustomerHistoryComponent},
 


{path:'banker/viewCreditQueries',component:ListCreditQueryComponent},
{path:'banker/viewUpgradeDebitQueries',component:ListUpgradeRequestsComponent},
{path:'banker/viewUpgradeCreditQueries',component:ListCreditUpdateRequestsComponent},
{path:'banker/viewDebitMismatchQueries',component:ListMismatchRequestsComponent},
{path:'banker/viewCreditMismatchQueries',component:ListCreditMismatchRequestsComponent},

]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
