import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-credit-list',
  templateUrl: './show-credit-list.component.html',
  styleUrls: ['./show-credit-list.component.css']
})
export class ShowCreditListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
