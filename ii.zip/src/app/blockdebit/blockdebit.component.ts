import { Component, OnInit } from '@angular/core';
import { Debitmodel } from '../model/debitmodel';
import { DebitserviceService } from '../service/debitservice.service';

@Component({
  selector: 'app-blockdebit',
  templateUrl: './blockdebit.component.html',
  styleUrls: ['./blockdebit.component.css']
})
export class BlockdebitComponent implements OnInit {
  bean: Debitmodel[];
  constructor(private debitService: DebitserviceService) { }

  ngOnInit() {
  }

  load() {
    console.log("enter1");
    this.debitService.getAll().subscribe(
      (data) => {
        console.log("enter");
        this.bean = data;
     
    }
      );
}
}
