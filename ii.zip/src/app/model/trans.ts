import { Debitmodel } from './debitmodel';

export class Trans {
    public transactionId:number;
    public accountNumber:number;
   public transactionDescription:String;
public transactionDate:Date;
public transactionAmount:number;
    public fromDate:Date ;   
    public endDate:Date ;   
    public cardNumber:number;
    public debitBeanObject:Debitmodel;
}
