import { CaseidBean } from './caseid-bean';

describe('CaseidBean', () => {
  it('should create an instance', () => {
    expect(new CaseidBean()).toBeTruthy();
  });
});
