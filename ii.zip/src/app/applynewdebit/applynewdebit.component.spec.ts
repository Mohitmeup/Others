import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplynewdebitComponent } from './applynewdebit.component';

describe('ApplynewdebitComponent', () => {
  let component: ApplynewdebitComponent;
  let fixture: ComponentFixture<ApplynewdebitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplynewdebitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplynewdebitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
