import { Component, OnInit } from '@angular/core';
import { DebitserviceService } from '../service/debitservice.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-applynewdebit',
  templateUrl: './applynewdebit.component.html',
  styleUrls: ['./applynewdebit.component.css']
})
export class ApplynewdebitComponent implements OnInit {

  constructor(private debitService: DebitserviceService) { }

  ngOnInit() {


  }



  applySilver(){
var type="Silver";
let cardDetails = {

  type

}
this.debitService.applyNewDebitCard(cardDetails).subscribe(

  data=>

  {
    console.log(data);
    if(data.value) {
        console.log(data.value);
  
        Swal.fire({
          title: 'Application Success!',
         text: data.message,
          confirmButtonText: 'DONE!'
        })}

        else{

          Swal.fire({
            title: 'Oops!',
           text: data.message,
            confirmButtonText: 'Cancel!'
          })


        }
          
         }
)
  }

  
  applyGold(){
    var type="Gold";
    let cardDetails = {
    
      type
    
    }
    this.debitService.applyNewDebitCard(cardDetails).subscribe(
    
      data=>
    
      {
        console.log(data);
        if(data.value) {
            console.log(data.value);
      
            Swal.fire({
              title: 'Application Success!',
             text: data.message,
              confirmButtonText: 'DONE!'
            })}
    
            else{
    
              Swal.fire({
                title: 'Oops!',
               text: data.message,
                confirmButtonText: 'Cancel!'
              })
    
    
            }
              
             }
    )
      }



      
  applyPlatinum(){
    var type="Platinum";
    let cardDetails = {
    
      type
    
    }
    this.debitService.applyNewDebitCard(cardDetails).subscribe(
    
      data=>
    
      {
        console.log(data);
        if(data.value) {
            console.log(data.value);
      
            Swal.fire({
              title: 'Application Success!',
             text: data.message,
              confirmButtonText: 'DONE!'
            })}
    
            else{
    
              Swal.fire({
                title: 'Oops!',
               text: data.message,
                confirmButtonText: 'Cancel!'
              })
    
    
            }
              
             }
    )
      }
}
