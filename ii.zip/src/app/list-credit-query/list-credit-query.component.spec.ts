import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListCreditQueryComponent } from './list-credit-query.component';

describe('ListCreditQueryComponent', () => {
  let component: ListCreditQueryComponent;
  let fixture: ComponentFixture<ListCreditQueryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListCreditQueryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListCreditQueryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
