import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GroupsComponent } from './groups/groups.component';
import { ContactsListComponent } from './contacts-list/contacts-list.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { SearchContactComponent } from './search-contact/search-contact.component';
import { DebitlistComponent } from './debitlist/debitlist.component';
import { CarddetailsComponent } from './carddetails/carddetails.component';
import { BlockdebitComponent } from './blockdebit/blockdebit.component';
import { UpgradeComponent } from './upgrade/upgrade.component';
import { CreditlistComponent } from './creditlist/creditlist.component';
import { ShowCardComponent } from './show-card/show-card.component';
import { DebitStatementComponent } from './debit-statement/debit-statement.component';
import { ApplynewdebitComponent } from './applynewdebit/applynewdebit.component';
import { ListQueryComponent } from './list-query/list-query.component';

import { BankComponent } from './bank/bank.component';
import { ListCreditQueryComponent } from './list-credit-query/list-credit-query.component';
import { ListUpgradeRequestsComponent } from './list-upgrade-requests/list-upgrade-requests.component';
import { ListMismatchRequestsComponent } from './list-mismatch-requests/list-mismatch-requests.component';
import { ListCreditMismatchRequestsComponent } from './list-credit-mismatch-requests/list-credit-mismatch-requests.component';
import { ListCreditUpdateRequestsComponent } from './list-credit-update-requests/list-credit-update-requests.component';
import { ShowCreditListComponent } from './show-credit-list/show-credit-list.component';
import { ViewRequestsComponent } from './view-requests/view-requests.component';
import { ViewCustomerHistoryComponent } from './view-customer-history/view-customer-history.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    GroupsComponent,
    ContactsListComponent,
    ContactFormComponent,
    SearchContactComponent,
    DebitlistComponent,
    CarddetailsComponent,
    BlockdebitComponent,
    UpgradeComponent,
    CreditlistComponent,
    ShowCardComponent,
    DebitStatementComponent,
    ApplynewdebitComponent,
    ListQueryComponent,
    BankComponent,
    ListCreditQueryComponent,
    ListUpgradeRequestsComponent,
    ListMismatchRequestsComponent,
    ListCreditMismatchRequestsComponent,
    ListCreditUpdateRequestsComponent,
    ShowCreditListComponent,
    ViewRequestsComponent,
    ViewCustomerHistoryComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [], 
  bootstrap: [AppComponent]
})
export class AppModule { }
