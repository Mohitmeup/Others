import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListUpgradeRequestsComponent } from './list-upgrade-requests.component';

describe('ListUpgradeRequestsComponent', () => {
  let component: ListUpgradeRequestsComponent;
  let fixture: ComponentFixture<ListUpgradeRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListUpgradeRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListUpgradeRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
