import { TestBed } from '@angular/core/testing';

import { CreditServiceService } from './credit-service.service';

describe('CreditServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CreditServiceService = TestBed.get(CreditServiceService);
    expect(service).toBeTruthy();
  });
});
