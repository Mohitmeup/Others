import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';

@Injectable({
  providedIn: 'root'
})
export class CreditServiceService {
  [x: string]: any;
  baseUrl: string;
  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/debit`;
  }
  getAll(): Observable<any> {
    console.log("abc")
    return this.http.get<any>(`${this.baseUrl}/debitlist`);

  }
  
}
