import { TestBed } from '@angular/core/testing';

import { BankerServiceService } from './banker-service.service';

describe('BankerServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BankerServiceService = TestBed.get(BankerServiceService);
    expect(service).toBeTruthy();
  });
});
