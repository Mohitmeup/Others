package com.cg.cardmanagement.controller;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CaseIdBean;
import com.cg.cardmanagement.service.CustomerService;


@CrossOrigin
@RestController
public class DefaultController {

	@Autowired
	private CustomerService customerService;

	@GetMapping(value = "/queryStatus")
	public ResponseEntity<List<CaseIdBean>> viewQueryStatus() throws IBSException {
		BigInteger uci =new BigInteger("7894561239632587");
		List<CaseIdBean>

		caseIdBeans = customerService.listAllQueries(uci);

		return new ResponseEntity<List<CaseIdBean>>(caseIdBeans, HttpStatus.OK);

	}
//
//	@GetMapping(value = "/displayServiceRequests/{customerRefId}")
//	public ResponseEntity<String> queryStatus(@PathVariable("customerRefId") String customerReferenceId)
//			throws IBSException {
//
//		String status = customerService.viewServiceRequestStatus(customerReferenceId);
//		String output = "Status of your request is '" + status + "'";
//		return new ResponseEntity<String>(output, HttpStatus.OK);
//
//	}

	@ExceptionHandler
	public ResponseEntity<String> ibsException(IBSException e) {

		String output = e.getMessage();
		return new ResponseEntity<String>(output, HttpStatus.OK);
	}

}
