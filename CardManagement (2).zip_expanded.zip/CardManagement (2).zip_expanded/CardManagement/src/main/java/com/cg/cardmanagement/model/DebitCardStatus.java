package com.cg.cardmanagement.model;

public enum DebitCardStatus {
	BLOCKED,ACTIVE,INACTIVE

}
