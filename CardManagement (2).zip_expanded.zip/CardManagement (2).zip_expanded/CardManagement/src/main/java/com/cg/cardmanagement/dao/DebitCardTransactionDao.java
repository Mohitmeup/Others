package com.cg.cardmanagement.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.Transaction;

public interface DebitCardTransactionDao {
	//List<DebitCardTransaction> getDebitTrans(int dys, BigInteger debitCardNumber) throws IBSException;

	

	BigInteger getDebitCardNumber(Integer transactionId) throws IBSException;

	BigInteger getDMUci(Integer transactionId) throws IBSException;

	boolean verifyDebitTransactionId(Integer transactionId) throws IBSException;



	Integer getDebitMismatchTranscId(String queryId) throws IBSException;



	Transaction getDebitMismatchTransc(Integer mismatchTransactionId) throws IBSException;



	List<Transaction> getDebitTrans(LocalDate startDate, LocalDate endDate, BigInteger debitCardNumber) throws IBSException;

	boolean checkTransactions(BigInteger debitCardNumber) throws IBSException;
}
