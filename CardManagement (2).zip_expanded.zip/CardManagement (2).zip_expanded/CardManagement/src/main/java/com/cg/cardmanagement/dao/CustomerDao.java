
package com.cg.cardmanagement.dao;

import java.math.BigInteger;

import com.cg.cardmanagement.exception.IBSException;

public interface CustomerDao {

	boolean verifyUCI(BigInteger uci) throws IBSException;

	String getNewName(BigInteger account) throws IBSException;

}
