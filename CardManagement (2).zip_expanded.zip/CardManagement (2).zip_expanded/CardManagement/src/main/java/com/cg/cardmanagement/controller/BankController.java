package com.cg.cardmanagement.controller;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.Banker;
import com.cg.cardmanagement.model.CardDetails;
import com.cg.cardmanagement.model.CaseIdBean;
import com.cg.cardmanagement.model.CreditCardTransaction;
import com.cg.cardmanagement.model.ReplyBean;
import com.cg.cardmanagement.model.Transaction;
import com.cg.cardmanagement.model.serviceRequests;
import com.cg.cardmanagement.service.BankService;
import com.cg.cardmanagement.service.DebitCustomer;

@CrossOrigin
@RestController
@RequestMapping("/banker")
public class BankController {

	@Autowired
	private BankService bankService;
	
	@Autowired
	private DebitCustomer debitService;

	@PostMapping(value = "/viewNewdebit")
	public ResponseEntity<List<CaseIdBean>> listNewDebitQueries(@RequestBody Banker b)
			throws IBSException {
	
        Integer bankerId=b.getBankerId();
        System.out.println(bankerId);
		List<CaseIdBean> caseBeans = bankService.viewNewDebitQueries(bankerId);
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@PostMapping("/viewDebitmismatch")
	public ResponseEntity<List<CaseIdBean>> debitMismatch(@RequestBody Banker b)
			throws IBSException {
		Integer bankerId=b.getBankerId();
		List<CaseIdBean> caseBeans = bankService.viewDebitMismatchQueries(bankerId);
		System.out.println("debmism"+caseBeans);
	
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@PostMapping("/viewCreditmismatch")
	public ResponseEntity<List<CaseIdBean>> creditMismatch(@RequestBody Banker b)
			throws IBSException {
		Integer bankerId=b.getBankerId();
		List<CaseIdBean> caseBeans = bankService.viewCreditMismatchQueries(bankerId);
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@PostMapping("/debitQueriesMismatch")
	public ResponseEntity<Transaction> replyDebitQueriesMismatch(@RequestBody CaseIdBean c)
			throws IBSException {
          String serviceRequest=c.getCaseIdTotal();
          System.out.println(serviceRequest);
		Integer mismatchTransactionId = bankService.getDebitTransactionId(serviceRequest);
System.out.println(mismatchTransactionId);
		Transaction debitCardBeanTrns = bankService.getDebitMismatchTransaction(mismatchTransactionId);
		System.out.println(debitCardBeanTrns);
		bankService.setBankTimeStamp(serviceRequest);
		return new ResponseEntity<Transaction>(debitCardBeanTrns, HttpStatus.OK);

	}

	@PostMapping("/creditQueriesMismatch")
	public ResponseEntity<CreditCardTransaction> replyCreditQueriesMismatch(
			@RequestBody CaseIdBean c) throws IBSException {
		 String serviceRequest=c.getCaseIdTotal();
		Integer mismatchTransactionId = bankService.getCreditTransactionId(serviceRequest);
		CreditCardTransaction creditCardBeanTrns = bankService.getCreditMismatchTransaction(mismatchTransactionId);
		bankService.setBankTimeStamp(serviceRequest);
		return new ResponseEntity<CreditCardTransaction>(creditCardBeanTrns, HttpStatus.OK);

	}

	@PostMapping("/mismatchDebitBlock")
	public ResponseEntity<CardDetails> replyQueriesDebit(@RequestBody ReplyBean r) throws IBSException {
	CardDetails output=new CardDetails();
	BigInteger cardNumber=r.getCardNumber();
	
	 if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Blocked")
             || debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Inactive")) {
     	
     	 output.setMessage( "You can not perform this function on "+debitService.getDebitcardStatus(cardNumber)+" card");
			output.setValue(false);
     }else {
			bankService.blockDebit(cardNumber);
			   output.setMessage( "You card has been blocked successfully.");
				output.setValue(true);
     }
		
	
		
			

		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}

	@PostMapping("/mismatchCreditBlock")
	public ResponseEntity<CardDetails> replyQueriesCredit(@RequestBody ReplyBean r) throws IBSException {
	CardDetails output=new CardDetails();
	BigInteger cardNumber=r.getCardNumber();
	String answer=r.getAnswer();
		if (answer.equalsIgnoreCase("Yes")) {
			bankService.blockCredit(cardNumber);
			  output.setMessage( "You card has been blocked successfully.");
				output.setValue(true);
		} else {
			output.setMessage( "You have chosen no");
			output.setValue(false);
		}
		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);
	}

	@PostMapping(value = "/replyQueries")
	public ResponseEntity<CardDetails> replyQueries(@RequestBody serviceRequests caseIdBean) throws IBSException {
		System.out.println("cvhnvnh");
	CardDetails output = new CardDetails();
	String status = caseIdBean.getStatusOfServiceRequest();
	System.out.println(status+"a");
		String serviceRequest = caseIdBean.getCaseIdTotal();

		String remarks = caseIdBean.getBankAdminRemarks();
		System.out.println(remarks);
System.out.println(status+"a");
		bankService.setQueryStatus(serviceRequest, status, remarks);
		 
        output.setMessage( "Replied successfully to the query");
		output.setValue(true);
		
		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}

	@PostMapping(value = "/viewNewcredit")
	public ResponseEntity<List<CaseIdBean>> listNewCreditQueries(@RequestBody Banker b)
			throws IBSException {
				Integer bankerId=b.getBankerId();
		List<CaseIdBean> caseBeans = bankService.viewNewCreditQueries(bankerId);
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@PostMapping(value = "/viewUpgradeDebit")
	public ResponseEntity<List<CaseIdBean>> listNewUpgradeDebitQueries(@RequestBody Banker b)
			throws IBSException {
		Integer bankerId=b.getBankerId();
		List<CaseIdBean> caseBeans = bankService.viewDebitUpgradeQueries(bankerId);
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);
	}

	@PostMapping(value = "/viewUpgradeCredit")
	public ResponseEntity<List<CaseIdBean>> listNewUpgradeCreditQueries(@RequestBody Banker b)
			throws IBSException {
		Integer bankerId=b.getBankerId();
		List<CaseIdBean> caseBeans = bankService.viewCreditUgradeQueries(bankerId);
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@ExceptionHandler(IBSException.class)
	public ResponseEntity<String> ibsException(IBSException e) {
		System.out.println(e);
		String output = e.getMessage();
		return new ResponseEntity<String>(output, HttpStatus.OK);
	}

	@GetMapping(value = "/viewCustomerHistory")
	public ResponseEntity<List<CaseIdBean>> listCustomerHistory()
			throws IBSException {
		BigInteger uci =new BigInteger("7894561239632587");
		List<CaseIdBean> caseBeans = bankService.viewCustomerHistory(uci);

		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

}
