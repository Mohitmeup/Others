package com.cg.cardmanagement.model;

import java.math.BigInteger;

public class AccBean {
	private BigInteger accountNumber;
	private BigInteger cardNumber;
		private String type;
	private String remarks;
	public BigInteger getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(BigInteger cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public BigInteger getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(BigInteger accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "AccBean [accountNumber=" + accountNumber + ", cardNumber=" + cardNumber + ", type=" + type
				+ ", remarks=" + remarks + "]";
	}
	public AccBean(BigInteger accountNumber, BigInteger cardNumber, String type, String remarks) {
		super();
		this.accountNumber = accountNumber;
		this.cardNumber = cardNumber;
		this.type = type;
		this.remarks = remarks;
	}
	public AccBean() {
		super();
	}
	

}
